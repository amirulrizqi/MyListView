package com.example.mylistview_syauqi

class Hero (
    var photo: Int,
    var name: String,
    var description: String
)